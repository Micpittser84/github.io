declare module '*.wav'
declare module '*.ogg'
declare module '*.mp3'
